<?php
    include 'config.php';

    if($_SESSION["user_role"] == '0'){
      header("Location: {$hostname}/admin/post.php");
    }
    $categoryid = $_GET["id"];

    /*sql to delete a record*/
    $sql = "DELETE FROM category WHERE category_id ='{$categoryid}'";

    if (mysqli_query($conn, $sql)) {
        header("location:{$hostname}/admin/category.php");
    }

    mysqli_close($conn);

?>
