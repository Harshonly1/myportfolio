<!DOCTYPE html>
<html lang="en">
<head>
  <title>Add user</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"> 
  <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <link rel="stylesheet" href="../css/style.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<?php 
include 'header.php';

if($_SESSION["user_role"] == '0'){
  header("Location: {$hostname}/admin/post.php");
}

if(isset($_POST['save'])){
include 'config.php';

$fname = mysqli_real_escape_string($conn,$_POST['fname']);
$lname = mysqli_real_escape_string($conn,$_POST['lname']);
$user = mysqli_real_escape_string($conn,$_POST['user']);
$password = mysqli_real_escape_string($conn,md5($_POST['password']));
$role = mysqli_real_escape_string($conn,$_POST['role']);

 $sql = "SELECT username FROM user WHERE username = '{$user}'";

$result = mysqli_query($conn, $sql) or die("Query Failed.");

if(mysqli_num_rows($result) > 0){
echo "<p style='color:red; text-align:center; margin: 10px 0;'>Username already Exists.</p>";
}else{
$sql1 = "INSERT INTO  user (`first_name`, `last_name`, `username`, `password`, `role`)
          VALUES ('{$fname}' , '{$lname}', '{$user}' , '{$password}' , '{$role}')";
   if(mysqli_query($conn,$sql1)){
    header("Location: {$hostname}/admin/users.php");
   }       
}
}
?>
<body>
    <div class="container mt-3">
        <div class="col-md-6 mx-auto">
        <h1 class="fw-bold">ADD USER</h1>
            <form action="<?php $_SERVER['PHP_SELF']; ?>" method="post" autocomplete="off">
            <label for="" class="form-label fw-bold">First Name</label>
            <input type="text" class="form-control"  name="fname">
            <br>
            <label for="" class="form-label fw-bold">Last Name</label>
            <input type="text" class="form-control"  name="lname">
            <br>
            <label for="" class="form-label fw-bold">User Name</label>
            <input type="text" class="form-control"  name="user">
            <br>
            <label for="" class="form-label fw-bold">Password</label>
            <input type="password" class="form-control"  name="password">
            <br>
            <label for="" class="form-label fw-bold">User Role</label>
            <select class="form-select" name="role" aria-label="Default select example">
              <option selected value="0">Normal</option>
              <option value="1">Admin</option>
            </select>
            <br>
            <button class="btn btn-primary" name="save" type="submit">Save</button>
            </form>
        </div>
    </div>
</body>
</html>