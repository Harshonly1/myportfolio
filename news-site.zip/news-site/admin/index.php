<?php 
include 'config.php';
session_start();

if(isset($_SESSION["username"])){
  header("Location: {$hostname}/admin/post.php");
}
?>

<!doctype html>
<html>
<head>
  <title>Admin</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"> 
  <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <link rel="stylesheet" href="../css/style.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>

    <body>
        <div class="container mt-5">
        <img src="./images/news.jpg" alt="" class="admin_logo">
          <div class="col-md-3 mt-3 mx-auto">
          <h2 class="h3">Admin</h2>
            <form action="<?php $_SERVER['PHP_SELF']; ?>" method="post">
            <label for="exampleFormControlInput1" class="form-label fw-bold">Username</label>
            <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter username" name="user_name">
            <br>
            <label for="" class="form-label fw-bold">Password</label>
            <input class="form-control" type="password" name="password" placeholder="Password"></input>
            <br>
            <button class="btn btn-primary" name="login" type="submit">login</button>
            </form>
            <?php 
              if(isset($_POST['login'])){
              include 'config.php';
              if(empty($_POST['user_name']) || empty($_POST['password'])){
                echo '<div class="alert alert-danger">All Fields must be entered.</div>';
                die();
              }else{
                $username = mysqli_real_escape_string($conn, $_POST['user_name']);
                $password = md5($_POST['password']);
            
                $sql = "SELECT `user_id`, `username`, `role` FROM `user` WHERE `username`='{$username}' AND `password`='{$password}'";
                $result = mysqli_query($conn, $sql) or die("Query Failed.");
            
                if(mysqli_num_rows($result) > 0){
                    while($row = mysqli_fetch_assoc($result)){
                        session_start();
                        $_SESSION["username"] = $row['username'];
                        $_SESSION["user_id"] = $row['user_id'];
                        $_SESSION["user_role"] = $row['role'];
                    
                        header("Location: {$hostname}/admin/users.php");
                        exit(); 
                    }                
              }else{
                      echo '<div class="alert alert-danger">Username and Password are not matched.</div>'; 
                  }
              }
              }
            ?>
          </div>
        </div>
    </body>
</html>