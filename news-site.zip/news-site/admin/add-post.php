<!DOCTYPE html>
<html lang="en">
<head>
  <title>ADD POST</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"> 
  <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <link rel="stylesheet" href="../css/style.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<?php 
include 'header.php';
?>
<body>

    <div class="container mt-3">
        <div class="col-md-6 mx-auto">
        <h1 class="fw-bold mb-3 ">ADD NEW POST</h1>
            <form action="save-post.php" method="post" enctype="multipart/form-data">
            <label for="" class="form-label fw-bold">Title</label>
            <input type="text" class="form-control"  name="post_title">
            <br>
            <label for="" class="form-label fw-bold">Description</label>
             <textarea class="form-control" name="post_desc" id="" rows="4" cols="50"></textarea>
            <br>
            <label for="" class="form-label fw-bold">Category</label>
            <select class="form-select" name="category" aria-label="Default select example">
              <option disabled selected>Select Category</option>
              <?php 
                include 'config.php';

                $sql = "SELECT * FROM category";

                $result = mysqli_query($conn, $sql) or die("Query Failed.");

                if(mysqli_num_rows($result) > 0){
                  while($row = mysqli_fetch_assoc($result)){
                    echo "<option value='{$row['category_id']}'>{$row['category_name']}</option>";
                  }
                }
              ?>
            </select>
            <br>
            <label for="" class="form-label fw-bold">Post Image</label>
            <input type="file" name="filetoupload" class="form-control" id="inputGroupFile04" aria-describedby="inputGroupFileAddon04" aria-label="Upload">
            <br>
            <button class="btn btn-primary" type="submit">Save</button>
            </form>
        </div>
    </div>
</body>
</html>
