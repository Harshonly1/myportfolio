<?php
include 'config.php';

if (empty($_FILES['new-image']['name'])) {
    $new_name = $_POST['old_image'];
} else {
    $errors = array();

    $file_name = $_FILES['new-image']['name'];
    $file_size = $_FILES['new-image']['size'];
    $file_tmp = $_FILES['new-image']['tmp_name'];
    $file_type = $_FILES['new-image']['type'];
    $file_ext = strtolower(end(explode('.', $file_name)));
    $extension = array("jpeg", "jpg", "png");

    if (!in_array($file_ext, $extension)) {
        $errors[] = "This extension file not allowed, Please choose a JPG or PNG file.";
    }

    if ($file_size > 2097152) {
        $errors[] = "File size must be 2mb or lower";
    }
    if($file_size > 2097152){
        $errors[] = "File size must be 2mb oe lower";
    }
    $new_name = time(). "-".basename($file_name);
    $target = "upload/".$new_name;
    $image_name = $new_name;
    if (empty($errors)) {
        move_uploaded_file($file_tmp, "upload/".$target);
    } else {
        print_r($errors);
        die();
    }
}

// Update post query
$sql_post = "UPDATE post SET `title`=?, `description`=?, `category`=?, `post_img`=? WHERE `post_id`=?";
$stmt_post = $conn->prepare($sql_post);
$stmt_post->bind_param("ssisi", $_POST["title"], $_POST["post_desc"], $_POST["category"], $image_name, $_POST["post_id"]);
$stmt_post->execute();
$stmt_post->close();

// Update category queries
if ($_POST['old_category'] != $_POST["category"]) {
    $sql_category_old = "UPDATE category SET post = post - 1 WHERE category_id = ?";
    $stmt_category_old = $conn->prepare($sql_category_old);
    $stmt_category_old->bind_param("i", $_POST['old_category']);
    $stmt_category_old->execute();
    $stmt_category_old->close();

    $sql_category_new = "UPDATE category SET post = post + 1 WHERE category_id = ?";
    $stmt_category_new = $conn->prepare($sql_category_new);
    $stmt_category_new->bind_param("i", $_POST["category"]);
    $stmt_category_new->execute();
    $stmt_category_new->close();
}

header("location: {$hostname}/admin/post.php");
?>
