<?php 
include 'header.php';

if($_SESSION["user_role"] == '0'){
  header("Location: {$hostname}/admin/post.php");
}

if(isset($_POST['update'])){
  include 'config.php';
  
  $categoryid = mysqli_real_escape_string($conn,$_POST['category_id']);
  $cname = mysqli_real_escape_string($conn,$_POST['category_name']);
  $npost = mysqli_real_escape_string($conn,$_POST['n_post']);
  
  if(isset($_GET['id'])) {
    $user_id = $_GET['id'];
    $sql = "UPDATE user SET `category_name` = '{$cname}', `n_post` = '{$npost}', WHERE category_id = {$categoryid}";
  
    if(mysqli_query($conn,$sql)){
      header("Location: category.php"); // Redirect to users.php after successful update
      exit(); // Stop further execution
    } else {
      echo "Error updating record: " . mysqli_error($conn);
    }
  } else {
    echo "No user ID provided.";
  }
}
?>
    <div class="container mt-5">
        <div class="col-md-6 mx-auto">
        <h1 class="fw-bold mt-3">UPDATE Category</h1>
        <?php 
        include 'config.php';
        if(isset($_GET['id'])) {
          $categoryid = $_GET['id'];
          $sql = "SELECT * FROM category WHERE category_id = $categoryid";
          $result= mysqli_query($conn, $sql) or die("Query Failed.");

          if(mysqli_num_rows($result) > 0){
            while($row = mysqli_fetch_assoc($result)){
      ?>

        <form action="<?php echo $_SERVER['PHP_SELF'] . '?id=' . $categoryid; ?>" method="post" autocomplete="off">
            <label for="" class="form-label fw-bold"></label>
            <input type="hidden" class="form-control" value="<?php echo $row['category_id']; ?>"  name="category_id">
            <br>
            <label for="" class="form-label fw-bold">Category Name</label>
            <input type="text" class="form-control" value="<?php echo $row['category_name']; ?>"  name="category_name">
            <br>
            <label for="" class="form-label fw-bold">No. of Post</label>
            <input type="text" class="form-control" value="<?php echo $row['post']; ?>"  name="n_post">
            <br>
            <button class="btn btn-primary" name="submit" type="submit">Update</button>
            </form>
            <?php 
            }
          }
        }
            
            ?>
        </div>
    </div>