<?php  
include 'header.php';

if(isset($_POST['update'])){
  include 'config.php';
  
  $userid = mysqli_real_escape_string($conn,$_POST['user_id']);
  $fname = mysqli_real_escape_string($conn,$_POST['f_name']);
  $lname = mysqli_real_escape_string($conn,$_POST['l_name']);
  $user = mysqli_real_escape_string($conn,$_POST['username']);
  $role = mysqli_real_escape_string($conn,$_POST['role']);
  
  if(isset($_GET['id'])) {
    $user_id = $_GET['id'];
    $sql = "UPDATE user SET `first_name` = '{$fname}', `last_name` = '{$lname}', `username` = '{$user}', `role` = '{$role}' WHERE user_id = {$userid}";
  
    if(mysqli_query($conn,$sql)){
      header("Location: users.php"); // Redirect to users.php after successful update
      exit(); // Stop further execution
    } else {
      echo "Error updating record: " . mysqli_error($conn);
    }
  } else {
    echo "No user ID provided.";
  }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Update Users</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"> 
  <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <link rel="stylesheet" href="../css/style.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
  <div class="container">
    
    <div class="col-md-6 mt-3 mx-auto">
    <h1 class="mt-3">Modify User Details</h1>
      <?php 
        include 'config.php';

        if($_SESSION["user_role"] == '0'){
          header("Location: {$hostname}/admin/post.php");
        }

        if(isset($_GET['id'])) {
          $user_id = $_GET['id'];
          $sql = "SELECT * FROM user WHERE user_id = $user_id";
          $result= mysqli_query($conn, $sql) or die("Query Failed.");

          if(mysqli_num_rows($result) > 0){
            while($row = mysqli_fetch_assoc($result)){
      ?>
    <form action="<?php echo $_SERVER['PHP_SELF'] . '?id=' . $user_id; ?>" method="post" autocomplete="off">
    
            <label for="" class="form-label fw-bold"></label>
            <input type="hidden" class="form-control" value="<?php echo $row['user_id']; ?>"  name="user_id">
            <br>
            <label for="" class="form-label fw-bold">First Name</label>
            <input type="text" class="form-control" value="<?php echo $row['first_name']; ?>"  name="f_name">
            <br>
            <label for="" class="form-label fw-bold">Last Name</label>
            <input type="text" class="form-control" value="<?php echo $row['last_name']; ?>"  name="l_name">
            <br>
            <label for="" class="form-label fw-bold">User Name</label>
            <input type="text" class="form-control" value="<?php echo $row['username']; ?>"  name="username">
            <br>
            <label for="" class="form-label fw-bold">User Role</label>
            <select class="form-select" name="role" aria-label="Default select example">
                <?php 
                if($row['role'] == 1){
                    echo "<option value=\"0\">Normal</option>
                          <option value=\"1\" selected>Admin</option>";
                } else {
                    echo "<option value=\"0\" selected>Normal</option>
                          <option value=\"1\">Admin</option>";
                }
                ?>
            </select>

            <br>
            <button class="btn btn-primary" name="update" type="submit">Update</button>
            </form>
            <?php 
              }
          }
        }
      ?>
    </div>
  </div>
</body>
</html>
