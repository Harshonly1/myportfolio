<!DOCTYPE html>
<html lang="en">
<head>
  <title>Add Category</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"> 
  <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <link rel="stylesheet" href="../css/style.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<?php 
include 'header.php';

if($_SESSION["user_role"] == '0'){
  header("Location: {$hostname}/admin/post.php");
}
?>
<body>
  
  <div class="container mt-3">
    <div class="row gutters-5">
      <div class="col-md-12">
      <div class="col-md-3 mt-3">
          <a href="add-category.php">
          <button type="button" class="btn btn-primary" style="margin-left: 1227px;">ADD CATEGORY</button>
          </a>
        </div>
      <?php 
          include 'config.php';
          $limit = 3;
          if (isset($_GET['page'])){
            $page = $_GET['page'];
          }else{
            $page = 1;
          }
          $offset = ($page - 1) * $limit;
          
          $sql = "SELECT * FROM category ORDER BY category_id DESC LIMIT {$offset},{$limit}";
          $result= mysqli_query($conn, $sql) or die("Query Failed.");

          if(mysqli_num_rows($result) > 0){
        ?>
      <table class="table table-hover table-striped ">
        <div class="row gutters-5">
        <div class="col-md-4">
        <h1 class="mt-3 fw-bold"> 
    ALL POST
  </h1>
        </div>
        
        </div>      
  <thead class="table-dark">
    <tr>
      <th scope="col">S.NO.</th>
      <th scope="col">CATEGORY NAME</th>
      <th scope="col">NO.OF POSTS</th>
      <th scope="col">EDIT</th>
      <th scope="col">DELETE</th>
    </tr>
  </thead>
  <tbody>
  <?php 
       $serial = $offset + 1;
    while($row = mysqli_fetch_assoc($result)){
    
    ?>
    <tr>
    <th scope="row"><?php echo  $serial ?></th>
      <td><?php echo strtoupper($row['category_name']); ?></td>
      <td><?php echo $row['post']; ?></td>
      <td><a href="update-category.php?id=<?php echo $row['category_id']; ?>">
      <img src="../images/icon_img/edit.png" alt="" style="margin-left: 11px;">
      </a></td>
      <td class="pull-right"><a href="delete-category.php?id=<?php echo $row['category_id']; ?>"><img src="../images/icon_img/delete.png" alt="" style="margin-left: 28px;"></a></td>
    </tr>
    <?php 
        $serial++;
  } 
  ?>
  </tbody>
</table>
<?php 
}

$sql1 = "SELECT * FROM category";
$result1 = mysqli_query($conn, $sql1) or die("Query Failed.");

if(mysqli_num_rows($result1) > 0){

  $total_records = mysqli_num_rows($result1);

  $total_page = ceil($total_records / $limit);
  echo '<nav aria-label="...">
  <ul class="pagination pagination-sm">';
  if($page > 1){
    echo '<li class="page-item"><a class="page-link" href="category.php?page='.($page - 1).'">Prev</a></li>';
  }
  for($i = 1; $i <= $total_page; $i++){
    if($i == $page){
    $active = "active";  
    }else{
      $active = ""; 
    }
    echo '<li class="page-item '.$active.'"><a class="page-link" href="category.php?page='.$i.'">'.$i.'</a></li>';
  } 
  if($total_page > $page){
    echo '<li class="page-item"><a class="page-link" href="category.php?page='.($page + 1).'">Next</a></li>';
  }

  echo "</ul>
        </nav>";
}
?>
<!-- <nav aria-label="...">
  <ul class="pagination pagination-sm">
    <li class="page-item active" aria-current="page">
      <span class="page-link">1</span>
    </li>
    <li class="page-item"><a class="page-link" href="#">2</a></li>
    <li class="page-item"><a class="page-link" href="#">3</a></li>
  </ul>
</nav> -->
      </div>
    </div>
  </div>
</body>
</html>