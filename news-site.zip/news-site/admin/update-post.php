<!DOCTYPE html>
<html lang="en">
<head>
  <title>Update</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"> 
  <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <link rel="stylesheet" href="../css/style.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<?php 
include 'header.php';
if($_SESSION['user_role'] == 0){
  include 'config.php';
  $post_id = $_GET['id'];
  $sql2 = "SELECT author FROM post WHERE post.post_id = {$post_id}";
  $result2= mysqli_query($conn, $sql2) or die("Query Failed.");

  $row2 = mysqli_fetch_assoc($result2);

  if($row2['author'] != $_SESSION['user_id']){
    header("location: {$hostname}/admin/post.php");
  }
}
?>
<body>

    <div class="container mt-3">
        <div class="col-md-6 mx-auto">
        <h1 class="fw-bold mt-3 ">UPDATE POST</h1>
          <?php 
          include 'config.php';

          $post_id = $_GET['id'];
          $sql = "SELECT post.post_id, post.title,post.description,category.category_name,post.post_img,post.category FROM post 
            LEFT JOIN category ON post.category = category.category_id
            LEFT JOIN user ON post.author = user.user_id
            WHERE post.post_id = {$post_id}";

          $result= mysqli_query($conn, $sql) or die("Query Failed.");

          if(mysqli_num_rows($result) > 0){
            while($row = mysqli_fetch_assoc($result)){

          ?>
            <form action="save-update-post.php" method="post">
            <input type="hidden" class="form-control" value="<?php echo $row['post_id']; ?>" name="post_id">
            <label for="" class="form-label fw-bold">Title</label>
            <input type="text" class="form-control" value="<?php echo $row['title']; ?>"  name="title">
            <br>
            <label for="" class="form-label fw-bold">Description</label>
             <textarea class="form-control" name="post_desc" id="" rows="3">
             <?php echo $row['description']; ?>
             </textarea>
            <br>
            <label for="" class="form-label fw-bold">Category</label>
            <select class="form-select" name="category" aria-label="Default select example">
            <option disabled>Select Category</option>
              <?php 
                include 'config.php';

                $sql1 = "SELECT * FROM category";

                $result1 = mysqli_query($conn, $sql1) or die("Query Failed.");

                if(mysqli_num_rows($result1) > 0){
                  while($row1 = mysqli_fetch_assoc($result1)){
                    if($row['category'] == $row1['category_id']){
                      $selected = "selected";
                    }else{
                      $selected = "";
                    }
                    echo "<option {$selected} value='{$row1['category_id']}'>{$row1['category_name']}</option>";
                  }
                }
              ?>
            </select>
            <input type="hidden" name="old_category" value="<?php echo $row['category']; ?>"> 
            <br>
            <label for="" class="form-label fw-bold">Post Image</label>
            <input type="file" class="form-control" name="new-image" id="inputGroupFile04" aria-describedby="inputGroupFileAddon04" aria-label="Upload">
            <br>
            <img src="upload/<?php echo $row['post_img']; ?>" height="150px" alt="">
            <input type="hidden" name="old_image" value="<?php echo $row['post_img'] ?>">
            <br>
            <br>
            <button class="btn btn-primary" name="submit" type="submit">Update</button>
            </form>
           <?php 
               }
            }else{
              echo 'Result not found';
            }
           ?>
        </div>
    </div>
</body>
</html>