<?php 
include 'config.php';
session_start();

if(!isset($_SESSION["username"])){
  header("Location: {$hostname}/admin/");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"> 
  <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <link rel="stylesheet" href="../css/style.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<div class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="collapse navbar-collapse justify-content-center bg-primary" id="navbarSupportedContent">
    <div class="navbar-nav row gutters-5" style="--bs-gutter-x: 80.5rem;">
    <div class="col-md-6">
            <img src="./images/news.jpg" class="logo1" alt="" width="100%">
            </div>
            <div class="col-md-6 mt-3">
                <a href="logout.php">
                    <h2 class="text-white col-md-3">Hello <?php echo strtoupper($_SESSION["username"]); ?>, LOGOUT</h2>
                </a>
            </div>
    </div>
  </div>
</div>
<nav class="navbar navbar-expand-lg bg-body-tertiary">
<div class="collapse navbar-collapse bg-light" id="navbarSupportedContent">
      <ul class="navbar-nav mb-2 mb-lg-0 admin_header">
        <li class="nav-item">
          <a class="nav-link active fw-bold text-primary" aria-current="page" href="post.php">POST</a>
        </li>
        <?php 
          if($_SESSION["user_role"] == '1'){
        ?>
        <li class="nav-item">
          <a class="nav-link active fw-bold text-primary" aria-current="page" href="category.php">CATEGORY</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active fw-bold text-primary" aria-current="page" href="users.php">USERS</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active fw-bold text-primary" aria-current="page" href="settings.php">SETTINGS</a>
        </li>
        <?php
          }
        ?>
      </ul> 
    </div>
</nav>
</body>
</html>